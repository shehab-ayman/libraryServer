/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmiclient;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import controller.*;
/**
 *
 * @author User
 */
public class adminRmiclient {
    
     public static void main(String[] args) throws RemoteException {
         
         addAdmingui addAdmingui= new addAdmingui();
         displayAllAdminsgui displayAdmingui = new displayAllAdminsgui();
         deleteAdmingui deleteAdmingui= new deleteAdmingui();
         updateAdmingui updateAdmingui= new updateAdmingui();
         retrieveAdmingui retrieveAdmingui = new retrieveAdmingui();
                  
        addAdmingui.setLocationRelativeTo(null); // This makes the window appears centered
        addAdmingui.setVisible(true); // This shows the gui
        //main.setVisible(true);
        
        displayAdmingui.setLocationRelativeTo(null); // This makes the window appears centered
        displayAdmingui.setVisible(true); // This shows the gui

        deleteAdmingui.setLocationRelativeTo(null); // This makes the window appears centered
        deleteAdmingui.setVisible(true); // This shows the gui
        
        updateAdmingui.setLocationRelativeTo(null); // This makes the window appears centered
        updateAdmingui.setVisible(true); // This shows the gui
        
        retrieveAdmingui.setLocationRelativeTo(null); // This makes the window appears centered
        retrieveAdmingui.setVisible(true); // This shows the gui
        
        Registry r = LocateRegistry.getRegistry(1099);
         // We connect to the RMI Registry
         
         // we create a new object from the controller and we pass it the
        // gui object along with the registry object
        addAdminController addAdmin_gui = new addAdminController(addAdmingui,r);
        displayAllAdminsController displayAllAdmins_gui = new displayAllAdminsController(displayAdmingui,r);
        deleteAdminController deleteAdmin_gui=new deleteAdminController(deleteAdmingui,r);
        updateAdminController updateAdmin_gui=new updateAdminController(updateAdmingui,r);
        retrieveAdminController retrieveAdmin_gui = new retrieveAdminController(retrieveAdmingui,r);
     }
    
}
