/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmiclient;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import controller.*;

/**
 *
 * @author Shehab
 */

public class bookRmiclient {
      
 public static void main(String[] args) throws RemoteException {
          findBook findBookgui = new findBook();
          bookMainWindow main = new bookMainWindow();
          borrowbookgui borrowbookgui = new borrowbookgui();
          ViewAllBorrowedBooks allborrowedbooksgui = new ViewAllBorrowedBooks();
        // We create an object from the GUI window
        
       findBookgui.setLocationRelativeTo(null); // This makes the window appears centered
        findBookgui.setVisible(true); // This shows the gui
        //main.setVisible(true);
        borrowbookgui.setLocationRelativeTo(null);
        borrowbookgui.setVisible(true);
        
        allborrowedbooksgui.setLocationRelativeTo(null);
        allborrowedbooksgui.setVisible(true);
        Registry r = LocateRegistry.getRegistry(1099);

        // We connect to the RMI Registry
        
        // we create a new object from the controller and we pass it the
        // gui object along with the registry object
        mainwindowcontroller gui_main = new mainwindowcontroller(main,r);
        FindBookContorller findbook_gui = new FindBookContorller(findBookgui, r);
        borrowBookController borrow_gui = new borrowBookController(borrowbookgui, r);
        viewAllBorrowedBooksController allborrow_gui = new viewAllBorrowedBooksController(allborrowedbooksgui, r);
    }
    
}
