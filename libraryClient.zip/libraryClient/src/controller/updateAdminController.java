/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import rmiclient.*;
import rmi.*;
/**
 *
 * @author User
 */
public class updateAdminController {
    
    updateAdmingui gui;
    Registry r;
    
    public updateAdminController(updateAdmingui gui, Registry r) {
        this.gui = gui;
        this.r = r;
        
      gui.getjButton1().addActionListener(new updateAdminController.update());
    }
    class update implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
          try{ 
              adminInterface a =(adminInterface) r.lookup("adminsubsystem");
              String adminId = gui.getjTextField1().getText();
              String username = gui.getjTextField2().getText();
              String password = gui.getjTextField3().getText();
              String adminName = gui.getjTextField4().getText();
              
              boolean check =  a.updateAdmin(username, password, adminId, adminName);
               if(check==true){
      
       JOptionPane.showMessageDialog(gui, "admin is updated");
       
       }
       else{
              JOptionPane.showMessageDialog(gui, "error occured");

       }
          }
           catch (RemoteException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NotBoundException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            }
}
    }
}