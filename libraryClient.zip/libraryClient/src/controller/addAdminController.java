/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import rmiclient.*;
import rmi.*;
/**
 *
 * @author User
 */
public class addAdminController {
    
    addAdmingui gui;
    Registry r;
    
        public addAdminController(addAdmingui gui, Registry r) {
        this.gui = gui;
        this.r = r;
        
      gui.getjButton1().addActionListener(new add());
    }
        class add implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
          try{ 
              adminInterface a =(adminInterface) r.lookup("adminsubsystem");
              String username = gui.getjTextField1().getText();
              String password = gui.getjTextField2().getText();
              String adminId = gui.getjTextField3().getText();
              String adminName = gui.getjTextField4().getText();
              
             
             boolean check =  a.addAdmin(username, password, adminId, adminName);
               if(check==true){
      
       JOptionPane.showMessageDialog(gui, "admin is added");
        
       }
       else{
              JOptionPane.showMessageDialog(gui, "error occured");

       }
          } 
          catch (RemoteException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NotBoundException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        }
}
