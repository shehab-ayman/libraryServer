/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import rmiclient.*;
import rmi.*;
/**
 *
 * @author User
 */

public class displayAllAdminsController {
    displayAllAdminsgui gui;
    Registry r;
    
    public displayAllAdminsController(displayAllAdminsgui gui, Registry r) {
        this.gui = gui;
        this.r = r;
        
        gui.getjButton1().addActionListener(new displayAllAdminsController.display());
    }
   class display implements ActionListener{
       @Override
        public void actionPerformed(ActionEvent ae) {
            try{
                adminInterface a =(adminInterface) r.lookup("adminsubsystem");
               // String AllAdmins = gui.getjLabel2().getText();
                
                String result =  a.displayAllAdmins();
                 gui.getjLabel2().setText(result);
            }
                catch (RemoteException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NotBoundException ex) {
                Logger.getLogger(FindBookContorller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
   }
}
